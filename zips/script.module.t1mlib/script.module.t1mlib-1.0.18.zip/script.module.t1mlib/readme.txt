script.module.t1mlib
================

Library of support routines for t1m addons

V1.0.18 increased urlopen timeout for Kodi 17 on Android
V1.0.15 change default cacheToDisc parm to False
V1.0.14 another unicode fix
V1.0.13 fix outfile.close()
V1.0.12 added post to getRequest
V1.0.11 add doFunction
V1.0.10 subtitle dxfp - > srt cleanup
V1.0.9 fix issue with unicode in url
V1.0.8 use setArt instead of init parms for ListItem
V1.0.7 cleanup for release
V1.0.6 fix for subtitles
V1.0.5 added getAddonCats
V1.0.4 fix request headers init
V1.0.3 cleanup
V1.0.2 fix for unicode
V1.0.1 Initial version
