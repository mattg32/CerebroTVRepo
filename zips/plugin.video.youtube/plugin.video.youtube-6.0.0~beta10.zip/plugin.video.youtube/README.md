
![](https://raw.githubusercontent.com/Kolifanes/plugin.video.youtube/master/icon.png)
# **Links:**

* [YouTube](http://www.youtube.com)
* [Support thread](http://forum.kodi.tv/showthread.php?tid=267160)

# **Images:**
![](https://i.imgur.com/WvJRshc.png)
![](https://i.imgur.com/imNpGdh.png)
![](https://i.imgur.com/xpKkCs9.png)
![](https://i.imgur.com/B3nCDSe.png)
