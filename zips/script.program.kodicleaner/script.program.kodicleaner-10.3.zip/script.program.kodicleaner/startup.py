import xbmc
xbmc.executebuiltin("XBMC.AlarmClock('PYOTIMER',XBMC.RunAddon(script.program.kodicleaner),345600,silent)")


	
